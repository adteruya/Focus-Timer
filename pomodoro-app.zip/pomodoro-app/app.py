from flask import Flask, render_template
import requests

app = Flask(__name__)

options = ['15:00', '25:00', '50:00']


def get_image():
    url = 'https://image-microservice-us.herokuapp.com/background'
    data = requests.get(url=url)
    image_url = data.text
    return image_url


@app.route("/")
def home():
    return render_template('index.html', options=options)


@app.route("/display")
def display():
    random_background = get_image()
    return render_template('image.html', image=random_background)


@app.route("/todo")
def todopage():
    return render_template('todo.html')


if __name__ == '__main__':
    app.run(debug=True)
