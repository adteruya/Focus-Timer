from threading import Thread
from time import sleep
import sys

'/Users/ana-teruya/.pyenv/versions/3.9.2/bin/python'

# Global variables to adjust timer state:
paused = False
running = False
canceled = False
t_remaining = None


def start(user_input):
    global t_remaining
    t_remaining = user_input
    timer(user_input)
    return


def timer(seconds):
    global t_remaining
    for i in range(seconds):
        global paused
        if paused:
            t_remaining = i
            print("Countdown paused.")
            break
        print(t_remaining - i, " seconds...")
        sleep(1)
    t_remaining = 0
    print("Countdown completed!")
    sys.exit()


def pause():
    global paused


if __name__ == '__main__':
    time_amount = 25
    t1 = Thread(target=start, args=(time_amount,))
    t2 = Thread(target=pause)
    t2.start()
    t1.start()

