import json
import requests


url = 'https://image-microservice-us.herokuapp.com/background'
data = requests.get(url=url)
image_url = data.text
print(image_url)

