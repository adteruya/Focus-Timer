from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)


@app.route("/", methods=['GET'])
def main():
    return render_template('information.html')


@app.route('/weather', methods=['GET', 'POST'])
def weather_by_zip():
    zip_code = request.args.get('zip')
    txt = None
    if zip_code is None:
        txt = "No input was received - please enter try again with the following format: " \
              "https://cs361-weather-microservice.herokuapp.com/weather?zip=90210"
        return render_template('weather.html', text=txt)
    if len(zip_code) > 5:
        txt = "Zip code is too long - please input a 5-digit zip into the " \
              "following url: https://cs361-weather-microservice.herokuapp.com/weather?zip=90210"
        return render_template('weather.html', text=txt)
    info = get_weather_info(zip_code)
    if info == "404":
        txt = "Invalid zip code - please try again."
        return render_template('weather.html', text=txt)
    return jsonify(info)


def get_weather_info(user_zip):
    # Get location information by zip code:
    api_key = '68f837644a3e28e3fed12c692fac10cd'
    zip_code = user_zip
    country_code = 'US'

    # API get request to retrieve location information by zip code (latitude and longitude coordinates):
    zipcode_url = 'http://api.openweathermap.org/geo/1.0/zip?zip=' + zip_code + ',' + country_code + '&appid=' + api_key
    zip_r = requests.get(url=zipcode_url)
    location_data = zip_r.json()

    # Check if passed zip code is valid:
    if 'cod' in location_data:
        return location_data['cod']
    else:
        lat = str(location_data['lat'])
        lon = str(location_data['lon'])

        # API get request to retrieve weather information
        weather_url = 'http://api.openweathermap.org/data/2.5/weather?lat=' + lat + '&lon=' + lon + '&appid=' \
                      + api_key + '&units=imperial'
        weather_r = requests.get(url=weather_url)
        weather_data = weather_r.json()

        # Set data:
        data = {
            'zip': location_data['zip'],
            'city': location_data['name'],
            'country': location_data['country'],
            'weather_description': weather_data['weather'][0]['main'],
            'temp_f': round(weather_data['main']['temp'], 1),
            'temp_c': round((weather_data['main']['temp'] - 32) / 1.8, 1)
        }
        return data


if __name__ == "__main__":
    app.run(debug=True)
